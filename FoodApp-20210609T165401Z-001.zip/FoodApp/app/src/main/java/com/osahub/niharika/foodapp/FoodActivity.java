package com.osahub.niharika.foodapp;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.weiwangcn.betterspinner.library.material.MaterialBetterSpinner;

import java.util.ArrayList;
import java.util.List;

public class FoodActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    MaterialBetterSpinner areaSpinner, localitySpinner;
    AppCompatButton update;
    TextView locationChange, locationText;
    SharedPreferences preferences, userPref;
    SharedPreferences.Editor editor, userEditor;
    Dialog dialog;
    List<String> areaList = new ArrayList<String>();
    List<String> subareaList = new ArrayList<String>();
    private String selectedArea, selectedSubarea;
    RecyclerView foodRecycler;
    List<FoodPojo> foodList = new ArrayList<>();
    DbHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        db = new DbHelper(getApplicationContext());
        foodRecycler = (RecyclerView) findViewById(R.id.foodRecycler);
        preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        editor = preferences.edit();
        userPref = getSharedPreferences("User Details", MODE_PRIVATE);
        userEditor = userPref.edit();

        List<FoodPojo> list = new ArrayList<>();
        foodList = db.fetchALLFoodData(db);
        for (int i = 0; i < foodList.size(); i++) {
            if (foodList.get(i).getCategory() == 1) {
                list.add(foodList.get(i));
            }
        }

        MyAdapter myAdapter = new MyAdapter(getApplicationContext(), list);
        myAdapter.setHasStableIds(true);
        foodRecycler.setAdapter(myAdapter);
        foodRecycler.setLayoutManager(new LinearLayoutManager(this));
        foodRecycler.invalidate();


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.cart);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CartActivity.class);
                startActivity(intent);
            }
        });

        locationChange = (TextView) findViewById(R.id.locationChange);
        locationText = (TextView) findViewById(R.id.locationText);

        if (userPref.getString("AREA", "").equals("") || userPref.getString("SUBAREA", "").equals("")) {
            setDialog();
        } else {
            String slocation = userPref.getString("AREA", "") + ", " + userPref.getString("SUBAREA", "");
            locationText.setText(slocation);
        }

        locationChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setDialog();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }

    public void setDialog() {

                 /*Dialog Views' Initialization */

        dialog = new Dialog(FoodActivity.this);
        dialog.setContentView(R.layout.location_dialog);
        areaSpinner = (MaterialBetterSpinner) dialog.findViewById(R.id.areaSpinner);
        localitySpinner = (MaterialBetterSpinner) dialog.findViewById(R.id.localitySpinner);
        update = (AppCompatButton) dialog.findViewById(R.id.update);

        for (String a : preferences.getStringSet("Areas", null)) {
            areaList.add(a);
        }

        /*Area Spinner Adapter */

        areaSpinner.setAdapter(new ArrayAdapter<String>(FoodActivity.this, R.layout.support_simple_spinner_dropdown_item, areaList));

        /*Listeners*/

        areaSpinner.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                selectedArea = areaList.get(i);
                for (String s : preferences.getStringSet(areaList.get(i), null)) {
                    subareaList.add(s);
                }
                localitySpinner.setAdapter(new ArrayAdapter<String>(FoodActivity.this, R.layout.support_simple_spinner_dropdown_item, subareaList));
                localitySpinner.setVisibility(View.VISIBLE);
            }
        });

        localitySpinner.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                selectedSubarea = subareaList.get(i);
                update.setVisibility(View.VISIBLE);
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update.setVisibility(View.GONE);
                userEditor.putString("AREA", selectedArea);
                userEditor.putString("SUBAREA", selectedSubarea);
                userEditor.commit();
                String slocation = userPref.getString("AREA", "") + ", " + userPref.getString("SUBAREA", "");
                locationText.setText(slocation);
                dialog.dismiss();
            }
        });

        /*Showing Dialog Finally after setting up*/

        dialog.show();

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.food, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();
        List<FoodPojo> list = new ArrayList<>();

        if (id == R.id.starters) {

            for (int i = 0; i < foodList.size(); i++) {
                if (foodList.get(i).getCategory() == 1) {
                    list.add(foodList.get(i));
                }
            }

            MyAdapter myAdapter = new MyAdapter(getApplicationContext(), list);
            myAdapter.setHasStableIds(true);
            foodRecycler.setAdapter(myAdapter);
            foodRecycler.setLayoutManager(new LinearLayoutManager(this));

        } else if (id == R.id.ff) {
            for (int i = 0; i < foodList.size(); i++) {
                if (foodList.get(i).getCategory() == 2) {
                    list.add(foodList.get(i));
                }
            }

            MyAdapter myAdapter = new MyAdapter(getApplicationContext(), list);
            myAdapter.setHasStableIds(true);
            foodRecycler.setAdapter(myAdapter);
            foodRecycler.setLayoutManager(new LinearLayoutManager(this));


        } else if (id == R.id.hm) {
            for (int i = 0; i < foodList.size(); i++) {
                if (foodList.get(i).getCategory() == 3) {
                    list.add(foodList.get(i));
                }
            }

            MyAdapter myAdapter = new MyAdapter(getApplicationContext(), list);
            myAdapter.setHasStableIds(true);
            foodRecycler.setAdapter(myAdapter);
            foodRecycler.setLayoutManager(new LinearLayoutManager(this));


        } else if (id == R.id.beverages) {
            for (int i = 0; i < foodList.size(); i++) {
                if (foodList.get(i).getCategory() == 4) {
                    list.add(foodList.get(i));
                }
            }

            MyAdapter myAdapter = new MyAdapter(getApplicationContext(), list);
            myAdapter.setHasStableIds(true);
            foodRecycler.setAdapter(myAdapter);
            foodRecycler.setLayoutManager(new LinearLayoutManager(this));


        } else if (id == R.id.about) {

        } else if (id == R.id.contact) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
