package com.osahub.niharika.foodapp;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class CartActivity extends AppCompatActivity {

    Dialog dialog;
    TextInputEditText name, email, mobile, address;
    AppCompatButton submit;
    RecyclerView cartRecycler;
    DbHelper db;
    TextView totalPayAmount;
    float totalAmount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        db = new DbHelper(this);
        totalPayAmount = (TextView) findViewById(R.id.totalPayAmount);
        cartRecycler = (RecyclerView) findViewById(R.id.cartRecycler);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.proceed);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog = new Dialog(CartActivity.this);
                dialog.setContentView(R.layout.dialog_layout);

                name = (TextInputEditText) dialog.findViewById(R.id.name);
                email = (TextInputEditText) dialog.findViewById(R.id.email);
                mobile = (TextInputEditText) dialog.findViewById(R.id.mobile);
                address = (TextInputEditText) dialog.findViewById(R.id.address);
                submit = (AppCompatButton) dialog.findViewById(R.id.submit);

                submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (name.getText().toString().equals("")) {
                            Toast.makeText(CartActivity.this, "Please Enter Name", Toast.LENGTH_SHORT).show();
                        } else if (email.getText().toString().equals("")) {
                            Toast.makeText(CartActivity.this, "Please Enter Email-ID", Toast.LENGTH_SHORT).show();
                        } else if (mobile.getText().toString().equals("")) {
                            Toast.makeText(CartActivity.this, "Please Enter Mobile No.", Toast.LENGTH_SHORT).show();
                        } else if (address.getText().toString().equals("")) {
                            Toast.makeText(CartActivity.this, "Please Enter Address", Toast.LENGTH_SHORT).show();
                        } else {
                            Intent intent = new Intent(getApplicationContext(), FoodActivity.class);
                            startActivity(intent);
                            finish();
                            Toast.makeText(CartActivity.this, "Order Placed Successfully", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                dialog.show();
            }
        });

        cartRecycler.setAdapter(new CartAdapter(CartActivity.this, db.fetchALLCartData(db),db.fetchALLFoodData(db)));
        cartRecycler.setLayoutManager(new LinearLayoutManager(CartActivity.this));

    }

    public void updateTotalValue(float cost) {
        totalAmount = cost;
        String txt = "Total Cart Value : " + String.valueOf(cost);
        totalPayAmount.setText(txt);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            NavUtils.navigateUpFromSameTask(this);
        }
        return super.onOptionsItemSelected(item);
    }
}
