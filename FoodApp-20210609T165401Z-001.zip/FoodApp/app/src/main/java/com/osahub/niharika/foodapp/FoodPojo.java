package com.osahub.niharika.foodapp;


public class FoodPojo {

    int id,category;
    float cost,weight;
    String name;
    byte[] pic;


    public FoodPojo(int id, int category, float cost, float weight, String name, byte[] pic) {
        this.id = id;
        this.category = category;
        this.cost = cost;
        this.weight = weight;
        this.name = name;
        this.pic = pic;
    }

    public FoodPojo() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getPic() {
        return pic;
    }

    public void setPic(byte[] pic) {
        this.pic = pic;
    }
}
