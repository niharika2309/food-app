package com.osahub.niharika.foodapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SplashActivity extends AppCompatActivity {

    Set<String> areas = new HashSet<String>(), area1 = new HashSet<String>(), area2 = new HashSet<String>(), area3 = new HashSet<String>();
    SharedPreferences preferences, userPref;
    SharedPreferences.Editor editor, userEditor;
    DbHelper dbHelper;
    List<FoodPojo> foodList=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        userPref = getSharedPreferences("User Details", MODE_PRIVATE);
        userEditor = userPref.edit();
        preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        editor = preferences.edit();
        dbHelper = new DbHelper(this);



        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                dbHelper.deleteAllFoodData(dbHelper);
                dbHelper.deleteAllCartData(dbHelper);

                if(!userPref.getBoolean("data",false)) {


                    areas.add("Janakpuri");
                    areas.add("Dwarka");
                    areas.add("Tilak Nagar");

                    area1.add("Block B1");
                    area1.add("Block B2");
                    area1.add("Block B3");
                    area1.add("Block C1");
                    area1.add("Block C2");


                    area2.add("Sector 11");
                    area2.add("Sector 12");
                    area2.add("Sector 13");
                    area2.add("Sector 14");
                    area2.add("Sector 18");

                    area3.add("Ashok Nagar");
                    area3.add("Manohar Nagar");
                    area3.add("Old Mahavir Nagar");
                    area3.add("Mukhram Garden");
                    area3.add("Prithvi Park");

              /*  for (int i = 0; i < 20 ; i++) {
                    foodList.add(new FoodPojo(i, 1, 5*i, 0.25f, "A"+ i, Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.ic_delete))));
                }

                dbHelper.insertFoodDataList(dbHelper,foodList);*/

                    dbHelper.insertFoodData(dbHelper, new FoodPojo(0, 1, 50.0f, 1.00f, "Chole bhature", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.chole))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(1, 1, 25.0f, 1.00f, "Aloo Tikki", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.tikki1))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(2, 1, 50.0f, 1.00f, "Dosa", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.dosa1))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(3, 1, 60.0f, 1.00f, "Pao Bhaji", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.pao))));
                 //   dbHelper.insertFoodData(dbHelper, new FoodPojo(4, 1, 30.0f, 1.00f, "Spring Rolls", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.ic_delete))));

                    dbHelper.insertFoodData(dbHelper, new FoodPojo(5, 2, 55.0f, 1.00f, "Burger", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.burger))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(6, 2, 90.0f, 1.00f, "Veg Pizza", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.pizza))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(7, 2, 60.0f, 1.00f, "Veg Noodles", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.noodles))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(8, 2, 40.0f, 1.00f, "Manchurian", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.manchu))));
                   // dbHelper.insertFoodData(dbHelper, new FoodPojo(9, 2, 50.0f, 1.00f, "Pasta", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.ic_delete))));

                    dbHelper.insertFoodData(dbHelper, new FoodPojo(10, 3, 30.0f, 1.0f, "Dal Makhni", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.dal1))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(11, 3, 50.0f, 1.00f, "Shahi Paneer", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.paneer))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(12, 3, 35.0f, 1.00f, "Rajma Chawal", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.raj))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(13, 3, 3.0f, 1.00f, "Roti", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.roti))));
                    //dbHelper.insertFoodData(dbHelper, new FoodPojo(14, 3, 3.0f, 1, "Roti", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.ic_cart))));

                    dbHelper.insertFoodData(dbHelper, new FoodPojo(15, 4, 20.0f, 1, "Coffee", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.coffee1))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(16, 4, 10.0f, 1, "tea", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.tea))));
                    //dbHelper.insertFoodData(dbHelper, new FoodPojo(17, 4, 35.0f, 1, "Cold drink", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.coffee1))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(18, 4, 40.0f, 1, "Cold coffee", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.cold))));
                    dbHelper.insertFoodData(dbHelper, new FoodPojo(19, 4,45.0f, 1, "MilkShake", Utility.getBytes(BitmapFactory.decodeResource(getResources(), R.drawable.milk))));

                    editor.putStringSet("Areas", areas);
                    editor.putStringSet("Janakpuri", area1);
                    editor.putStringSet("Dwarka", area2);
                    editor.putStringSet("Tilak Nagar", area3);

                    editor.apply();
                    Intent intent = new Intent(getApplicationContext(), FoodActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    userEditor.putBoolean("data",true);
                    userEditor.commit();
                    Intent intent = new Intent(getApplicationContext(), FoodActivity.class);
                    startActivity(intent);
                    finish();
                }

            }
        }, 1800);

    }
}
