package com.osahub.niharika.foodapp;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Mahendroo on 18-07-2016.
 */
public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyHolder> {

    List<FoodPojo> foodPojos = new ArrayList<>();
    Context context;
    float finalWeight, weightFactor, currentWeight;
    DbHelper db;

    public MyAdapter(Context context, List<FoodPojo> list) {
        this.context = context;
        this.foodPojos = list;
        db = new DbHelper(context.getApplicationContext());
        notifyDataSetChanged();
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.food_layout, parent, false);
        MyHolder holder = new MyHolder(view);
        return holder;
    }

    @Override
    public int getItemCount() {
        return foodPojos.size();
    }

    @Override
    public void onBindViewHolder(final MyHolder holder, int position) {

        String cost = "₹ " + String.valueOf(foodPojos.get(position).getCost()) + " Per Unit";


        holder.foodname.setText(foodPojos.get(position).getName());
        holder.foodcost.setText(cost);
        holder.weight.setText(String.valueOf(foodPojos.get(position).getWeight()));
        holder.foodpic.setImageBitmap(Utility.getPhoto(foodPojos.get(position).getPic()));

        holder.plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weightFactor = db.fetchFoodData(db, foodPojos.get(holder.getAdapterPosition()).getId()).getWeight();
                currentWeight = Float.valueOf(holder.weight.getText().toString());
                finalWeight = weightFactor + currentWeight;
                holder.weight.setText(String.valueOf(finalWeight));
            }
        });
        holder.minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weightFactor = db.fetchFoodData(db, foodPojos.get(holder.getAdapterPosition()).getId()).getWeight();
                currentWeight = Float.valueOf(holder.weight.getText().toString());
                if (currentWeight > weightFactor) {
                    finalWeight = currentWeight - weightFactor;
                    holder.weight.setText(String.valueOf(finalWeight));
                }
            }
        });
        holder.addtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FoodPojo foodPojo = new FoodPojo();

                foodPojo = foodPojos.get(holder.getAdapterPosition());
                foodPojo.setWeight(Float.valueOf(holder.weight.getText().toString()));

                if (!db.checkCartData(db, foodPojo.getId())) {
                    db.insertCartData(db, foodPojo);
                } else {
                    db.updateCartData(db, foodPojo, foodPojo.getId());
                }

                String fullName = foodPojos.get(holder.getAdapterPosition()).getName();
                String toastMessageAddToCart = String.valueOf(foodPojo.getWeight()) + " Unit of " + fullName + " added to Cart";
                Toast.makeText(context, toastMessageAddToCart, Toast.LENGTH_SHORT).show();
            }
        });

    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView foodname, foodcost, weight;
        ImageView foodpic;
        Button minus, plus, addtocart;

        public MyHolder(View itemView) {
            super(itemView);
            foodpic = (ImageView) itemView.findViewById(R.id.foodpic);
            foodname = (TextView) itemView.findViewById(R.id.foodname);
            foodcost = (TextView) itemView.findViewById(R.id.foodcost);
            plus = (Button) itemView.findViewById(R.id.plus);
            minus = (Button) itemView.findViewById(R.id.minus);
            addtocart = (Button) itemView.findViewById(R.id.addtocart);
            weight = (TextView) itemView.findViewById(R.id.weight);
        }
    }
}
