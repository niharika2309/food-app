package com.osahub.niharika.foodapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Mahendroo on 17-07-2016.
 */
public class DbHelper extends SQLiteOpenHelper {

    final static String DATABASE_NAME = "food.db";
    final static int DATABASE_VERSION = 1;
    final static String CART_TABLE = "cart_data";
    final static String[] cartList = {"id", "name", "cost", "weight", "category", "pic"};
    final static String FOOD_TABLE = "food_data";
    final static String[] foodList = {"id", "name", "cost", "weight", "category", "pic"};
    final static String USER_TABLE = "user_data";
    final static String[] userList = {"id", "name", "email", "password"};

    final static int CI_id = 0;
    final static int CI_name = 1;
    final static int CI_cost = 2;
    final static int CI_weight = 3;
    final static int CI_category = 4;
    final static int CI_pic = 5;

    final static int UD_id = 0;
    final static int UD_name = 1;
    final static int UD_email = 2;
    final static int UD_pwd = 3;

    List<FoodPojo> list = new ArrayList<>();

    String createCartTable = "create table " + CART_TABLE + "(" +
            "id integer PRIMARY KEY," +
            "name varchar ," +
            "cost float(4)," +
            "weight float(2)," +
            "category varchar," +
            "pic blob);";

    String createFoodTable = "create table " + FOOD_TABLE + "(" +
            "id integer PRIMARY KEY," +
            "name varchar ," +
            "cost float(4)," +
            "weight float(2)," +
            "category varchar," +
            "pic blob);";


    String createUserTable = "create table " + USER_TABLE + "(" +
            "id integer PRIMARY KEY AUTOINCREMENT," +
            "name varchar ," +
            "email varchar," +
            "password varchar);";

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(createFoodTable);
        db.execSQL(createCartTable);
        db.execSQL(createUserTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertUserData(DbHelper db, UserPojo up) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(userList[0], 0);
        cv.put(userList[1], up.getName());
        cv.put(userList[2], up.getEmail());
        cv.put(userList[3], up.getPassword());

        sqLiteDatabase.insert(USER_TABLE, null, cv);
    }

    public UserPojo checkUserData(DbHelper db, String email, String password) {
        UserPojo userPojo = new UserPojo();
        SQLiteDatabase sqLiteDatabase = db.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.query(CART_TABLE, cartList, userList[2] + "=? AND" + userList[3] + "=?", new String[]{email, password}, null, null, null);
        if (cursor.moveToFirst()) {
            userPojo = new UserPojo(cursor.getString(1), cursor.getString(2), cursor.getString(3));
        }

        return userPojo;
    }

    public void insertCartData(DbHelper db, FoodPojo sp) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(cartList[0], sp.getId());
        cv.put(cartList[1], sp.getName());
        cv.put(cartList[2], sp.getCost());
        cv.put(cartList[3], sp.getWeight());
        cv.put(cartList[4], sp.getCategory());
        cv.put(cartList[5], sp.getPic());

        sqLiteDatabase.insert(CART_TABLE, null, cv);
    }


    public void updateCartData(DbHelper db, FoodPojo sp, int id) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(cartList[0], sp.getId());
        cv.put(cartList[1], sp.getName());
        cv.put(cartList[2], sp.getCost());
        cv.put(cartList[3], sp.getWeight());
        cv.put(cartList[4], sp.getCategory());
        cv.put(cartList[5], sp.getPic());

        sqLiteDatabase.update(CART_TABLE, cv, cartList[0] + "=?", new String[]{String.valueOf(id)});
    }

    public void deleteCartData(DbHelper db, int id) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();

        sqLiteDatabase.delete(CART_TABLE, cartList[0] + "=?", new String[]{String.valueOf(id)});
    }

    public void deleteAllCartData(DbHelper db) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();

        sqLiteDatabase.delete(CART_TABLE, null, null);
    }

    public boolean checkCartData(DbHelper db, int id) {
        boolean flag = false;
        SQLiteDatabase sqLiteDatabase = db.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.query(CART_TABLE, cartList, cartList[0] + "=?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor.moveToFirst()) {
            flag = true;
        }

        return flag;
    }

    public boolean checkCartAllData(DbHelper db) {
        boolean flag = false;
        SQLiteDatabase sqLiteDatabase = db.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.query(CART_TABLE, cartList, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            flag = true;
        }

        return flag;
    }

    public List<FoodPojo> fetchALLCartData(DbHelper db) {
        SQLiteDatabase sqLiteDatabase = db.getReadableDatabase();
        List<FoodPojo> list = new ArrayList<>();
        Cursor cursor = sqLiteDatabase.query(CART_TABLE, cartList, null, null, null, null, null);
        if (cursor.moveToFirst()) {

            do {
                FoodPojo foodPojo = new FoodPojo();

                foodPojo.setId(cursor.getInt(CI_id));
                foodPojo.setName(cursor.getString(CI_name));
                foodPojo.setCost(cursor.getFloat(CI_cost));
                foodPojo.setWeight(cursor.getFloat(CI_weight));
                foodPojo.setCategory(cursor.getInt(CI_category));
                foodPojo.setPic(cursor.getBlob(CI_pic));

                list.add(foodPojo);

            }
            while (cursor.moveToNext());
        }

        return list;
    }


    public void insertFoodData(DbHelper db, FoodPojo sp) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(foodList[0], sp.getId());
        cv.put(foodList[1], sp.getName());
        cv.put(foodList[2], sp.getCost());
        cv.put(foodList[3], sp.getWeight());
        cv.put(foodList[4], sp.getCategory());
        cv.put(foodList[5], sp.getPic());

        sqLiteDatabase.insert(FOOD_TABLE, null, cv);
    }

    public void insertFoodDataList(DbHelper db, List<FoodPojo> list) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        for (int i = 0; i < list.size(); i++) {
            cv.put(foodList[0], list.get(i).getId());
            cv.put(foodList[1], list.get(i).getName());
            cv.put(foodList[2], list.get(i).getCost());
            cv.put(foodList[3], list.get(i).getWeight());
            cv.put(foodList[4], list.get(i).getCategory());
            cv.put(foodList[5], list.get(i).getPic());

            sqLiteDatabase.insert(FOOD_TABLE, null, cv);
        }
    }

    public void updateFoodData(DbHelper db, FoodPojo sp, int id) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(foodList[0], sp.getId());
        cv.put(foodList[1], sp.getName());
        cv.put(foodList[2], sp.getCost());
        cv.put(foodList[3], sp.getWeight());
        cv.put(foodList[4], sp.getCategory());
        cv.put(foodList[5], sp.getPic());

        sqLiteDatabase.update(FOOD_TABLE, cv, foodList[0] + "=?", new String[]{String.valueOf(id)});
    }

    public void deleteFoodData(DbHelper db, int id) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();

        sqLiteDatabase.delete(FOOD_TABLE, foodList[0] + "=?", new String[]{String.valueOf(id)});
    }

    public void deleteAllFoodData(DbHelper db) {
        SQLiteDatabase sqLiteDatabase = db.getWritableDatabase();

        sqLiteDatabase.delete(FOOD_TABLE, null, null);
    }

    public float checkFoodData(DbHelper db, int id) {
        float weight = 0.0f;
        SQLiteDatabase sqLiteDatabase = db.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.query(FOOD_TABLE, foodList, foodList[0] + "=?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor.moveToFirst()) {
            weight = cursor.getFloat(CI_weight);
        }

        return weight;
    }

    public List<FoodPojo> fetchALLFoodData(DbHelper db) {
        SQLiteDatabase sqLiteDatabase = db.getReadableDatabase();
        List<FoodPojo> list = new ArrayList<>();

        Cursor cursor = sqLiteDatabase.query(FOOD_TABLE, foodList, null, null, null, null, null);
        if (cursor.moveToFirst()) {

            do {
                FoodPojo foodPojo = new FoodPojo();

                foodPojo.setId(cursor.getInt(CI_id));
                foodPojo.setName(cursor.getString(CI_name));
                foodPojo.setCost(cursor.getFloat(CI_cost));
                foodPojo.setWeight(cursor.getFloat(CI_weight));
                foodPojo.setCategory(cursor.getInt(CI_category));
                foodPojo.setPic(cursor.getBlob(CI_pic));

                list.add(foodPojo);

            }
            while (cursor.moveToNext());
        }

        return list;
    }


    public FoodPojo fetchFoodData(DbHelper db, int id) {
        SQLiteDatabase sqLiteDatabase = db.getReadableDatabase();
        FoodPojo foodPojo = new FoodPojo();

        Cursor cursor = sqLiteDatabase.query(FOOD_TABLE, foodList, foodList[0] + "=?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor.moveToFirst()) {

            foodPojo.setId(cursor.getInt(CI_id));
            foodPojo.setName(cursor.getString(CI_name));
            foodPojo.setCost(cursor.getFloat(CI_cost));
            foodPojo.setWeight(cursor.getFloat(CI_weight));
            foodPojo.setCategory(cursor.getInt(CI_category));
            foodPojo.setPic(cursor.getBlob(CI_pic));

        }

        return foodPojo;
    }


}

