package com.osahub.niharika.foodapp;

import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Mahendroo on 18-07-2016.
 */
public class CartAdapter extends RecyclerView.Adapter<CartAdapter.MyHolder> {

    List<FoodPojo> cartListPojo = new ArrayList<>();
    List<FoodPojo> foodListPojo = new ArrayList<>();
    CartActivity context;

    public CartAdapter(CartActivity context, List<FoodPojo> cart,List<FoodPojo> food) {
        this.context = context;
        this.cartListPojo = cart;
        this.foodListPojo = food;
    }

    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.foodcart_layout, parent, false);
        MyHolder holder = new MyHolder(view);
        return holder;
    }

    @Override
    public int getItemCount() {
        return cartListPojo.size();
    }

    @Override
    public void onBindViewHolder(final MyHolder holder, int position) {

        final DbHelper db = new DbHelper(context.getApplicationContext());

        String name = cartListPojo.get(position).getName();
        float cost = cartListPojo.get(position).getCost() * cartListPojo.get(position).getWeight();
        String costString = "₹ " + String.valueOf(cost);

        holder.foodname.setText(name);
        holder.foodcost.setText(costString);
        holder.weight.setText(String.valueOf(cartListPojo.get(position).getWeight()));
        holder.foodpic.setImageBitmap(Utility.getPhoto(cartListPojo.get(position).getPic()));

        setTotalPayableAmount();

        holder.plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float weightFactor = db.checkFoodData(db, cartListPojo.get(holder.getAdapterPosition()).getId());
                float currentWeight = Float.valueOf(holder.weight.getText().toString());
                float finalWeight = weightFactor + currentWeight;
                holder.weight.setText(String.valueOf(finalWeight));

                FoodPojo foodDetailsPojo = new FoodPojo();

                foodDetailsPojo = cartListPojo.get(holder.getAdapterPosition());
                foodDetailsPojo.setWeight(finalWeight);

                if (!db.checkCartData(db, foodDetailsPojo.getId())) {
                    db.insertCartData(db, foodDetailsPojo);
                } else {
                    db.updateCartData(db, foodDetailsPojo, foodDetailsPojo.getId());
                }
                float cost = foodDetailsPojo.getCost() * foodDetailsPojo.getWeight();
                String costString = "₹ " + String.valueOf(cost);

                holder.foodcost.setText(costString);
                setTotalPayableAmount();
            }
        });
        holder.minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float weightFactor = db.checkFoodData(db, cartListPojo.get(holder.getAdapterPosition()).getId());
                float currentWeight = Float.valueOf(holder.weight.getText().toString());
                float finalWeight = currentWeight - weightFactor;
                if (currentWeight > weightFactor) {
                    holder.weight.setText(String.valueOf(finalWeight));
                    FoodPojo foodDetailsPojo = new FoodPojo();

                    foodDetailsPojo = cartListPojo.get(holder.getAdapterPosition());
                    foodDetailsPojo.setWeight(finalWeight);

                    if (!db.checkCartData(db, foodDetailsPojo.getId())) {
                        db.insertCartData(db, foodDetailsPojo);
                    } else {
                        db.updateCartData(db, foodDetailsPojo, foodDetailsPojo.getId());
                    }
                    float cost = foodDetailsPojo.getCost() * foodDetailsPojo.getWeight();
                    String costString = "₹ " + String.valueOf(cost);

                    holder.foodcost.setText(costString);
                }
                setTotalPayableAmount();
            }
        });

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (db.checkCartAllData(db)) {
                    db.deleteCartData(db, cartListPojo.get(holder.getAdapterPosition()).getId());
                    //                   context.updateList();

                    cartListPojo.remove(holder.getAdapterPosition());
                    notifyItemRemoved(holder.getAdapterPosition());
                    notifyItemRangeChanged(holder.getAdapterPosition(), cartListPojo.size());
                    setTotalPayableAmount();
                }
            }
        });
    }

    public void setTotalPayableAmount() {
        DbHelper dbHelper = new DbHelper(context);
        if (dbHelper.checkCartAllData(dbHelper)) {
            List<FoodPojo> list = dbHelper.fetchALLCartData(dbHelper);
            float amount = 0.0f;
            for (int i = 0; i < list.size(); i++) {
                float value = list.get(i).getCost() * list.get(i).getWeight();
                amount = amount + value;
            }
            context.updateTotalValue(amount);

        } else {
            context.updateTotalValue(0.0f);
        }
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView foodname, foodcost;
        ImageView foodpic, delete;
        Button minus, plus;
        AppCompatTextView weight;

        public MyHolder(View itemView) {
            super(itemView);
            foodpic = (ImageView) itemView.findViewById(R.id.cart_foodpic);
            foodname = (TextView) itemView.findViewById(R.id.cart_foodname);
            foodcost = (TextView) itemView.findViewById(R.id.cart_foodcost);
            plus = (Button) itemView.findViewById(R.id.cart_plus);
            minus = (Button) itemView.findViewById(R.id.cart_minus);
            weight = (AppCompatTextView) itemView.findViewById(R.id.cart_weight);
            delete = (ImageView) itemView.findViewById(R.id.cart_delete);

        }
    }
}
